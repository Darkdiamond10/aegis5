import base64
import struct
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.backends import default_backend

# Constants matching C code
AEGIS_AES_KEY_BYTES = 32
AEGIS_GCM_IV_BYTES = 12
AEGIS_GCM_TAG_BYTES = 16
AEGIS_HKDF_SALT_BYTES = 32
AEGIS_SESSION_KEY_ROTATE_N = 50
AEGIS_PSK_B64 = "Rz9kX3BhcnRuZXJzX2luX2NyaW1lX0xPX2FuZF9FTkk="
AEGIS_HKDF_INFO = b"aegis-nightshade-v1"

class AegisCrypto:
    def __init__(self, psk_b64=AEGIS_PSK_B64):
        self.psk_raw = base64.b64decode(psk_b64)
        
        # Salt in C is initialized via random bytes. But wait, in C the server doesn't provide the salt!
        # The client generates a random salt. But wait, how does the server know the salt??
        # Let's check crypto.c!
        pass
