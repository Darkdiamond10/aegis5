import sys

with open('/app/c2_comms/c2_client.c', 'r') as f:
    content = f.read()

target = """        rc = aegis_decrypt(ctx->crypto, resp_ct, resp_ct_len, body,
                           sizeof(aegis_c2_envelope_t) - AEGIS_GCM_IV_BYTES -
                               AEGIS_GCM_TAG_BYTES,
                           resp_env->iv, resp_env->tag, task_out);"""

replacement = """        aegis_c2_envelope_t aad_env;
        memcpy(&aad_env, resp_env, sizeof(aegis_c2_envelope_t));
        memset(aad_env.iv, 0, AEGIS_GCM_IV_BYTES);
        memset(aad_env.tag, 0, AEGIS_GCM_TAG_BYTES);
        
        rc = aegis_decrypt(ctx->crypto, resp_ct, resp_ct_len, (const uint8_t *)&aad_env,
                           sizeof(aegis_c2_envelope_t),
                           resp_env->iv, resp_env->tag, task_out);"""

if target in content:
    content = content.replace(target, replacement)
    with open('/app/c2_comms/c2_client.c', 'w') as f:
        f.write(content)
    print("Decryption AAD Patch applied for beacon!")
else:
    print("Decryption AAD beacon target not found.")

