import sys

with open('/app/c2_comms/c2_client.c', 'r') as f:
    content = f.read()

target_decrypt_payload = """  rc = aegis_decrypt(ctx->crypto, res_ct, res_ct_len, body,
                     sizeof(aegis_c2_envelope_t), resp_env->iv, resp_env->tag,
                     *res_out);"""

replacement_decrypt_payload = """  aegis_c2_envelope_t aad_env;
  memcpy(&aad_env, resp_env, sizeof(aegis_c2_envelope_t));
  memset(aad_env.iv, 0, AEGIS_GCM_IV_BYTES);
  memset(aad_env.tag, 0, AEGIS_GCM_TAG_BYTES);

  rc = aegis_decrypt(ctx->crypto, res_ct, res_ct_len, (const uint8_t *)&aad_env,
                     sizeof(aegis_c2_envelope_t), resp_env->iv, resp_env->tag,
                     *res_out);"""

if target_decrypt_payload in content:
    content = content.replace(target_decrypt_payload, replacement_decrypt_payload)
    with open('/app/c2_comms/c2_client.c', 'w') as f:
        f.write(content)
    print("Decryption AAD Patch applied for resource fetch!")
else:
    print("Decryption AAD payload target not found.")

