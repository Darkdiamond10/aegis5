import sys

with open('/app/c2_server/server.py', 'r') as f:
    content = f.read()

target = """        if env and ct:
            # We must decrypt the beacon to mathematically progress the server's AES-GCM sequence!
            # The client used the envelope WITH ZERO IV AND TAG as AAD.
            aad_env = bytearray(data[:ENVELOPE_SIZE])
            aad_env[ENVELOPE_SIZE - 32:ENVELOPE_SIZE - 16] = b'\\x00' * 16 # tag
            aad_env[ENVELOPE_SIZE - 44:ENVELOPE_SIZE - 32] = b'\\x00' * 12 # iv
            try:
                # Decrypting automatically increments SERVER_CRYPTO counters to match the client
                decrypted_task = SERVER_CRYPTO.decrypt(ct, env["iv"], env["tag"], bytes(aad_env))
                log_print(f"  └─ Decrypted Beacon Payload ({len(decrypted_task)} bytes)", Colors.CYAN)
            except Exception as e:
                log_print(f"  └─ Failed to decrypt beacon: {e}", Colors.FAIL)"""

# In the C struct:
# magic (4), msg_type (4), payload_len (4), sequence (4), iv (12), tag (16), node_id (16)
# total = 60
# iv offset = 16
# tag offset = 28
replacement = """        if env and ct:
            # We must decrypt the beacon to mathematically progress the server's AES-GCM sequence!
            # The client used the envelope WITH ZERO IV AND TAG as AAD.
            aad_env = bytearray(data[:ENVELOPE_SIZE])
            
            # offsets: iv is bytes 16 to 28, tag is bytes 28 to 44
            aad_env[16:28] = b'\\x00' * 12 # iv
            aad_env[28:44] = b'\\x00' * 16 # tag
            
            try:
                # Decrypting automatically increments SERVER_CRYPTO counters to match the client
                decrypted_task = SERVER_CRYPTO.decrypt(ct, env["iv"], env["tag"], bytes(aad_env))
                log_print(f"  └─ Decrypted Beacon Payload ({len(decrypted_task)} bytes)", Colors.CYAN)
            except Exception as e:
                log_print(f"  └─ Failed to decrypt beacon: {e}", Colors.FAIL)"""

if target in content:
    content = content.replace(target, replacement)
    with open('/app/c2_server/server.py', 'w') as f:
        f.write(content)
    print("Server Beacon Fix applied!")
else:
    print("Server Beacon target not found.")

