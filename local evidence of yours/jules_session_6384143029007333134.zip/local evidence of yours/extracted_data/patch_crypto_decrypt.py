import sys

with open('/app/c2_server/server_crypto.py', 'r') as f:
    content = f.read()

target = """    def decrypt(self, ciphertext: bytes, iv: bytes, tag: bytes, aad: bytes = None) -> bytes:
        aesgcm = AESGCM(self.session_key)
        
        # Cryptography expects ciphertext + tag
        payload = aesgcm.decrypt(iv, ciphertext + tag, aad)
        
        return payload"""

# I need to increment counter when decrypting to keep symmetry with C code
replacement = """    def decrypt(self, ciphertext: bytes, iv: bytes, tag: bytes, aad: bytes = None) -> bytes:
        # Increment counters
        self.msg_counter += 1
        self.total_messages += 1

        aesgcm = AESGCM(self.session_key)
        
        # Cryptography expects ciphertext + tag
        payload = aesgcm.decrypt(iv, ciphertext + tag, aad)
        
        return payload"""

if target in content:
    content = content.replace(target, replacement)
    with open('/app/c2_server/server_crypto.py', 'w') as f:
        f.write(content)
    print("Crypto decrypt patch applied!")
else:
    print("Crypto decrypt target not found.")

