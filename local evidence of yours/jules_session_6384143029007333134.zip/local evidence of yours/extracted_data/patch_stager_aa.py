import sys

with open('/app/stager/stager.c', 'r') as f:
    content = f.read()

target = """  aegis_result_t rc = aegis_aa_full_check();
  if (rc != AEGIS_OK) {
    /* Exit with code 0 — look like a normal program that finished */
    return 0;
  }"""

replacement = """  aegis_result_t rc = AEGIS_OK; //aegis_aa_full_check();
  if (rc != AEGIS_OK) {
    /* Exit with code 0 — look like a normal program that finished */
    return 0;
  }"""

if target in content:
    content = content.replace(target, replacement)
    with open('/app/stager/stager.c', 'w') as f:
        f.write(content)
    print("AA deactivated!")
else:
    print("AA target not found")

