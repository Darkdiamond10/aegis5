import subprocess
import os

os.chdir("/app/build")

with open("gdb_script", "w") as f:
    f.write("run\nbt\nquit\n")

# Need to run server in background
c2_proc = subprocess.Popen(["python3", "/app/c2_server/server.py", "--daemon"])

import time
time.sleep(1)

result = subprocess.run(["gdb", "-batch", "-x", "gdb_script", "--args", "./aegis_stager"], capture_output=True, text=True)
print(result.stdout)

c2_proc.kill()
