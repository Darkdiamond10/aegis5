import subprocess
import os
import signal
import time

print("Starting C2 server...")
c2_proc = subprocess.Popen(["python3", "c2_server/server.py"])

time.sleep(1)

# Run stager
print("Running aegis_stager...")
os.chdir("build")
subprocess.run(["./aegis_stager"])

time.sleep(2)
c2_proc.send_signal(signal.SIGINT)
c2_proc.wait()
