import subprocess
import os
import signal
import time

print("Starting build...")
subprocess.run(["make", "clean"])
subprocess.run(["make", "all"])

print("Starting C2 server...")
c2_proc = subprocess.Popen(["python3", "c2_server/server.py", "--daemon"])

time.sleep(1)

# Run stager test
print("Running stager...")
os.chdir("build")
result = subprocess.run(["./aegis_stager"])
print(f"Stager returned: {result.returncode}")

c2_proc.send_signal(signal.SIGINT)
c2_proc.wait()
