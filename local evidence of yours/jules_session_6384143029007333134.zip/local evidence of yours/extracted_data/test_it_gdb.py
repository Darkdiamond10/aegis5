import subprocess
import os
import signal
import time

print("Starting C2 server...")
c2_proc = subprocess.Popen(["python3", "c2_server/server.py", "--daemon"])

time.sleep(1)

# Run stager test
print("Running stager with GDB...")
os.chdir("build")

with open("gdb_script", "w") as f:
    f.write("run\nbt\nquit\n")

result = subprocess.run(["gdb", "-batch", "-x", "gdb_script", "--args", "./aegis_stager"], capture_output=True, text=True)
print(result.stdout)
print(result.stderr)

c2_proc.send_signal(signal.SIGINT)
c2_proc.wait()
